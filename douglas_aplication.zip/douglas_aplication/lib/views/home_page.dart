import 'package:douglas_aplication/Models/post.dart';
import 'package:flutter/material.dart';
import 'package:douglas_aplication/views/add_post.dart';
import 'package:douglas_aplication/views/post_item.dart';
import 'package:douglas_aplication/views/story_item.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Post> _posts = [Post(title: 'Post 1', text: 'Text 1'), Post(title: 'Post 2', text: 'Text 2'), Post(title: 'Post 3', text: 'Text 3')];
  final List _stories = ['story 1', 'story ', 'story 3', 'story 4', 'story 5'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Instagram",
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150,
            child: ListView.builder(
              itemCount: _stories.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return StoryItem(text: _stories[index]);
              },
            ),
          ),

          Expanded(
            child: ListView.builder(
              itemCount: _posts.length,
              itemBuilder: (context, index) {
                return PostItem(post: _posts[_posts.length - index - 1]);
              },
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddPost()),
          );
          if (result != null) {
            setState(() {
              _posts.add(result[0]);
            });
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
