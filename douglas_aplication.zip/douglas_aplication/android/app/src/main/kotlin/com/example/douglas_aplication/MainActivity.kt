package com.example.douglas_aplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
